# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
import os
import numpy as np
import psycopg2
from django.shortcuts import render_to_response
#import MySQLdb
#from ProfileStats.models import ProfileStats

# Create your views here.
import json
import collections

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def profile2012(request):
	json_data = os.path.join(BASE_DIR, 'balancesheet/static/json', "result2012.json")
	data = open(json_data).read()
	data2 = json.dumps(data) # json formatted string
	#rows = profileStatsData()
	rows = profileStatsData2012()
	#return render(request, 'balancesheet/test.html', {'data': data2,}, content_type='application/xhtml+xml')
	return render(request, 'balancesheet/profiles.html', {'data': data2,'row':rows})


def profile2013(request):
	json_data = os.path.join(BASE_DIR, 'balancesheet/static/json', "result2013.json")
	data = open(json_data).read()
	data2 = json.dumps(data) # json formatted string
	rows = profileStatsData2013()
	#return render(request, 'balancesheet/test.html', {'data': data2,}, content_type='application/xhtml+xml')
	return render(request, 'balancesheet/profiles.html', {'data': data2,'row':rows})



def profile2014(request):
	json_data = os.path.join(BASE_DIR, 'balancesheet/static/json', "result2014.json")
	data = open(json_data).read()
	data2 = json.dumps(data) # json formatted string
	rows = profileStatsData2014()
	#return render(request, 'balancesheet/test.html', {'data': data2,}, content_type='application/xhtml+xml')
	return render(request, 'balancesheet/profiles.html', {'data': data2,'row':rows})


def profile2015(request):
	json_data = os.path.join(BASE_DIR, 'balancesheet/static/json', "result2015.json")
	data = open(json_data).read()
	data2 = json.dumps(data) # json formatted string
	rows = profileStatsData2015()
	#return render(request, 'balancesheet/test.html', {'data': data2,}, content_type='application/xhtml+xml')
	return render(request, 'balancesheet/profiles.html', {'data': data2,'row':rows})


def avarageProfile(request):
	json_data = os.path.join(BASE_DIR, 'balancesheet/static/json', "resultAva.json")
	data = open(json_data).read()
	data2 = json.dumps(data) # json formatted string
	rows = profileStatsData()
	return render(request, 'balancesheet/profiles.html', {'data': data2,'row':rows})


def index(request):	
	return render(request, 'balancesheet/index.html', {})

def profiles(request):	
	return render(request, 'balancesheet/profiles.html', {})

def convert(data):
    if isinstance(data, basestring):
        return str(data)
    elif isinstance(data, collections.Mapping):
        return dict(map(convert, data.iteritems()))
    elif isinstance(data, collections.Iterable):
        return type(data)(map(convert, data))
    else:
        return data

def profileStatsData():
	""" query data from the vendors table """
	rows = []
	profile_array = {}
	conn = psycopg2.connect(database="munimoney", user="postgres", password="46926461@Lejaka", host="127.0.0.1", port="5432")
	#conn = None
	try:
		conn = psycopg2.connect(database="munimoney", user="postgres", password="46926461@Lejaka", host="127.0.0.1", port="5432")
		cur = conn.cursor()
        
        
		for i in range(1,5):
			cur.execute("SELECT mun_code, profile from profiles where profile=%i" %(i))
			rows = cur.fetchall()
			profile_num = len(rows)
			profile_array[i] = profile_num      
			#cur.close()

	except (Exception, psycopg2.DatabaseError) as error:
		print(error)

	finally:
		if conn is not None:
		    #conn.close()
			print("Connection closed")

	#print(profile_array)	
	rows = [profile_array]
	print(rows)
	#rows = dict(map(reversed, rows))

    #rows = [{'1':15, '2':54, '3':100, '4':7}]
    
	#rows = convert(rows)
	#print(rows)
	return rows

def profileStatsData2012():
	""" query data from the vendors table """
	rows12 = []
	profile_array = {}
	conn = psycopg2.connect(database="munimoney", user="postgres", password="46926461@Lejaka", host="127.0.0.1", port="5432")
	#conn = None
	try:
		conn = psycopg2.connect(database="munimoney", user="postgres", password="46926461@Lejaka", host="127.0.0.1", port="5432")
		cur = conn.cursor()
        
        
		for i in range(1,5):
			cur.execute("SELECT mun_code, profile from profiles where fin_date='2012' AND profile=%i" %(i))
			rows = cur.fetchall()
			profile_num = len(rows)
			profile_array[i] = profile_num      
			#cur.close()

	except (Exception, psycopg2.DatabaseError) as error:
		print(error)

	finally:
		if conn is not None:
		    #conn.close()
			print("Connection closed")

	#print(profile_array)	
	rows12 = [profile_array]
	print(rows12)
	#rows = dict(map(reversed, rows))

    #rows = [{'1':15, '2':54, '3':100, '4':7}]
    
	#rows = convert(rows)
	#print(rows)
	return rows12
	
def profileStatsData2013():
	""" query data from the vendors table """
	rows13 = []
	profile_array = {}
	conn = psycopg2.connect(database="munimoney", user="postgres", password="46926461@Lejaka", host="127.0.0.1", port="5432")
	#conn = None
	try:
		conn = psycopg2.connect(database="munimoney", user="postgres", password="46926461@Lejaka", host="127.0.0.1", port="5432")
		cur = conn.cursor()
        
        
		for i in range(1,5):
			cur.execute("SELECT mun_code, profile from profiles where fin_date='2013' AND profile=%i" %(i))
			rows = cur.fetchall()
			profile_num = len(rows)
			profile_array[i] = profile_num      
			#cur.close()

	except (Exception, psycopg2.DatabaseError) as error:
		print(error)

	finally:
		if conn is not None:
		    #conn.close()
			print("Connection closed")

	#print(profile_array)	
	rows13 = [profile_array]
	print(rows13)
	#rows = dict(map(reversed, rows))

    #rows = [{'1':15, '2':54, '3':100, '4':7}]
    
	#rows = convert(rows)
	#print(rows)
	return rows13
	
def profileStatsData2014():
	""" query data from the vendors table """
	rows14 = []
	profile_array = {}
	conn = psycopg2.connect(database="munimoney", user="postgres", password="46926461@Lejaka", host="127.0.0.1", port="5432")
	#conn = None
	try:
		conn = psycopg2.connect(database="munimoney", user="postgres", password="46926461@Lejaka", host="127.0.0.1", port="5432")
		cur = conn.cursor()
        
        
		for i in range(1,5):
			cur.execute("SELECT mun_code, profile from profiles where fin_date='2014' AND profile=%i" %(i))
			rows = cur.fetchall()
			profile_num = len(rows)
			profile_array[i] = profile_num      
			#cur.close()

	except (Exception, psycopg2.DatabaseError) as error:
		print(error)

	finally:
		if conn is not None:
		    #conn.close()
			print("Connection closed")

	#print(profile_array)	
	rows14 = [profile_array]
	print(rows14)
	#rows = dict(map(reversed, rows))

    #rows = [{'1':15, '2':54, '3':100, '4':7}]
    
	#rows = convert(rows)
	#print(rows)
	return rows14
	
def profileStatsData2015():
	""" query data from the vendors table """
	rows15 = []
	profile_array = {}
	conn = psycopg2.connect(database="munimoney", user="postgres", password="46926461@Lejaka", host="127.0.0.1", port="5432")
	#conn = None
	try:
		conn = psycopg2.connect(database="munimoney", user="postgres", password="46926461@Lejaka", host="127.0.0.1", port="5432")
		cur = conn.cursor()
        
        
		for i in range(1,5):
			cur.execute("SELECT mun_code, profile from profiles where fin_date='2015' AND profile=%i" %(i))
			rows = cur.fetchall()
			profile_num = len(rows)
			profile_array[i] = profile_num      
			#cur.close()

	except (Exception, psycopg2.DatabaseError) as error:
		print(error)

	finally:
		if conn is not None:
		    #conn.close()
			print("Connection closed")

	#print(profile_array)	
	rows15 = [profile_array]
	print(rows15)
	#rows = dict(map(reversed, rows))

    #rows = [{'1':15, '2':54, '3':100, '4':7}]
    
	#rows = convert(rows)
	#print(rows)
	return rows15
		
			
def profileStats(request):
    
    return render_to_response('balancesheet/dbTest.html', {})
			







	
