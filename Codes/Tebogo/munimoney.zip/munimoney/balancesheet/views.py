# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
import os

# Create your views here.
import json

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def profile2012(request):
	json_data = os.path.join(BASE_DIR, 'balancesheet/static/json', "result2012.json")
	
	data = open(json_data).read()
	data2 = json.dumps(data) # json formatted string


	#return render(request, 'balancesheet/test.html', {'data': data2,}, content_type='application/xhtml+xml')
	return render(request, 'balancesheet/profiles.html', {'data': data2,})

def profile2013(request):
	json_data = os.path.join(BASE_DIR, 'balancesheet/static/json', "result2013.json")
	
	data = open(json_data).read()
	data2 = json.dumps(data) # json formatted string


	#return render(request, 'balancesheet/test.html', {'data': data2,}, content_type='application/xhtml+xml')
	return render(request, 'balancesheet/profiles.html', {'data': data2,})

def profile2013(request):
	json_data = os.path.join(BASE_DIR, 'balancesheet/static/json', "result2013.json")
	
	data = open(json_data).read()
	data2 = json.dumps(data) # json formatted string


	#return render(request, 'balancesheet/test.html', {'data': data2,}, content_type='application/xhtml+xml')
	return render(request, 'balancesheet/profiles.html', {'data': data2,})

def profile2014(request):
	json_data = os.path.join(BASE_DIR, 'balancesheet/static/json', "result2014.json")
	
	data = open(json_data).read()
	data2 = json.dumps(data) # json formatted string


	#return render(request, 'balancesheet/test.html', {'data': data2,}, content_type='application/xhtml+xml')
	return render(request, 'balancesheet/profiles.html', {'data': data2,})

def profile2015(request):
	json_data = os.path.join(BASE_DIR, 'balancesheet/static/json', "result2015.json")
	
	data = open(json_data).read()
	data2 = json.dumps(data) # json formatted string


	#return render(request, 'balancesheet/test.html', {'data': data2,}, content_type='application/xhtml+xml')
	return render(request, 'balancesheet/profiles.html', {'data': data2,})

def avarageProfile(request):
	json_data = os.path.join(BASE_DIR, 'balancesheet/static/json', "resultAva.json")
	
	data = open(json_data).read()
	data2 = json.dumps(data) # json formatted string
	return render(request, 'balancesheet/profiles.html', {'data': data2,})

def index(request):	
	return render(request, 'balancesheet/index.html', {})

def profiles(request):	
	return render(request, 'balancesheet/profiles.html', {})
