from django.db import models

# Create your models here.
class BalSheet(models.Model):
	total_amount = models.DecimalField(max_digits=20,decimal_places=2)
	fin_year = models.DateTimeField()
	account_type = models.TextField()
	label = models.TextField()
	mun_name = models.TextField()
	mun_code = models.CharField(max_length=5)
	province = models.TextField()
	latitude = models.TextField()
	longitude = models.TextField()


	def __str__(self):
		return self.mun_name
	
