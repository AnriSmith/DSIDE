from django.conf.urls import url, include
from django.views.generic import ListView, DetailView
from balancesheet.models import BalSheet

from django.conf.urls import url

from . import views

#urlpatterns = [url(r'^$', ListView.as_view(queryset=BalSheet.objects.all().order_by("fin_year")[:25],
#					template_name="balancesheet/test.html")),
#					url(r'^(?P<pk>\d+)$', DetailView.as_view(model= BalSheet,
#						template_name = 'balancesheet/post.html'))]

urlpatterns = [
    # ex: /polls/
    #url(r'^$', views.frontPage, name='frontPage'),
	url(r'^$', views.index, name='index'),
	url(r'^profile2012', views.profile2012, name='Profile2012'),
	url(r'^profile2013', views.profile2013, name='Profile2013'),
	url(r'^profile2014', views.profile2014, name='Profile2014'),
	url(r'^profile2015', views.profile2015, name='Profile2015'),
	url(r'^avarageProfile', views.avarageProfile, name='avarageProfile'),
	url(r'^profiles', views.profiles, name='profiles'),
	url(r'^profileStats', views.profileStats, name='profileStats'),
	

    
]
