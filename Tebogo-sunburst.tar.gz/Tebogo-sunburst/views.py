# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
import os
from django.shortcuts import render_to_response
#import MySQLdb
#from ProfileStats.models import ProfileStats

# Create your views here.
import json
import csv
import pickle
from sklearn import svm
import math
import pandas

from django.http import HttpResponse

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def profile2012(request):
	json_data = os.path.join(BASE_DIR, 'balancesheet/static/json', "result2012.json")
	
	data = open(json_data).read()
	data2 = json.dumps(data) # json formatted string


	#return render(request, 'balancesheet/test.html', {'data': data2,}, content_type='application/xhtml+xml')
	return render(request, 'balancesheet/profiles.html', {'data': data2,})

def profile2013(request):
	json_data = os.path.join(BASE_DIR, 'balancesheet/static/json', "result2013.json")
	
	data = open(json_data).read()
	data2 = json.dumps(data) # json formatted string


	#return render(request, 'balancesheet/test.html', {'data': data2,}, content_type='application/xhtml+xml')
	return render(request, 'balancesheet/profiles.html', {'data': data2,})

def profile2013(request):
	json_data = os.path.join(BASE_DIR, 'balancesheet/static/json', "result2013.json")
	
	data = open(json_data).read()
	data2 = json.dumps(data) # json formatted string


	#return render(request, 'balancesheet/test.html', {'data': data2,}, content_type='application/xhtml+xml')
	return render(request, 'balancesheet/profiles.html', {'data': data2,})

def profile2014(request):
	json_data = os.path.join(BASE_DIR, 'balancesheet/static/json', "result2014.json")
	
	data = open(json_data).read()
	data2 = json.dumps(data) # json formatted string


	#return render(request, 'balancesheet/test.html', {'data': data2,}, content_type='application/xhtml+xml')
	return render(request, 'balancesheet/profiles.html', {'data': data2,})

def profile2015(request):
	json_data = os.path.join(BASE_DIR, 'balancesheet/static/json', "result2015.json")
	
	data = open(json_data).read()
	data2 = json.dumps(data) # json formatted string


	#return render(request, 'balancesheet/test.html', {'data': data2,}, content_type='application/xhtml+xml')
	return render(request, 'balancesheet/profiles.html', {'data': data2,})

def avarageProfile(request):
	json_data = os.path.join(BASE_DIR, 'balancesheet/static/json', "resultAva.json")
	
	data = open(json_data).read()
	data2 = json.dumps(data) # json formatted string
	return render(request, 'balancesheet/profiles.html', {'data': data2,})

def sunburstData(name):
	dataname = name + ".csv"		
	sun_data_list = []
	sun_data = os.path.join(BASE_DIR, 'balancesheet/static/sunburst', dataname)
	with open(sun_data, 'r') as csvfile:
		spamreader = csv.reader(csvfile)
		for row in spamreader:
			sun_data_list.append(row)
	data = ""
	total = 0 
	for row in sun_data_list:
		data += row[0] + "," + row[1] + "\n"
		#values[row[0]] = row[1]
		total += float(row[1])
	return data, total


def sunburst(request):
	profile1,total1 = sunburstData('Sunburst_profile1')
	profile2,total2 = sunburstData('Sunburst_profile2')
	#return render(request, 'balancesheet/sunburst2.html', {'profile1': profile1, 'total1': total1, 'profile2': profile2, 'total2': total2})
	return render(request, 'balancesheet/sunburst2.html', {'data': [profile1, total1, profile2, total2]})

def burst2013(request):
	profile1,total1 = sunburstData('IncProp_profile1_2013')
	profile2,total2 = sunburstData('IncProp_profile2_2013')
	#return render(request, 'balancesheet/sunburst2.html', {'profile1': profile1, 'total1': total1, 'profile2': profile2, 'total2': total2})
	return render(request, 'balancesheet/sunburst2.html', {'data': [profile1, total1, profile2, total2]})

def burst2014(request):
	profile1,total1 = sunburstData('IncProp_Profile1_2014')
	profile2,total2 = sunburstData('IncProp_profile2_2014')
	#return render(request, 'balancesheet/sunburst2.html', {'profile1': profile1, 'total1': total1, 'profile2': profile2, 'total2': total2})
	return render(request, 'balancesheet/sunburst2.html', {'data': [profile1, total1, profile2, total2]})

def burst2015(request):
	profile1,total1 = sunburstData('IncProp_profile1_2015')
	profile2,total2 = sunburstData('IncProp_profile2_2015')
	#return render(request, 'balancesheet/sunburst2.html', {'profile1': profile1, 'total1': total1, 'profile2': profile2, 'total2': total2})
	return render(request, 'balancesheet/sunburst2.html', {'data': [profile1, total1, profile2, total2]})



def index(request):	
	return render(request, 'balancesheet/index.html', {})



def profiles(request):	
	return render(request, 'balancesheet/profiles.html', {})

def profileStats(request):
	data55 = "this is a python string" 
	#ProfileStats.objects.all()
	return TemplateResponse(request, 'balancesheet/home.html', {'data55': data55})


#POSTING SVM
#WHAT YOU IMPORT DIFFERES DEPENDING ON YOUR VERSION OF DJANGO INSTALLED, 
#SO CHECK THE DOCUMENT FOR THE EQUIVALENT FUNCTION IN YOUR INSTALLED VERSION OF DJANGO

from django.views.decorators.csrf import ensure_csrf_cookie

def SVM(request):
	
	the_data = request.POST
	print(request.POST) 
			
	#STEP1: empty dataframe
	user_input = pd.DataFrame()	

	#STEP2: loop through dict, add values across columns
	for i in range(0, len()):

			
			
			#print(the_data)
			key = the_data["reclassify"]
			category  = the_data["category"]

			filename = '/home/dside/Documents/Django/balancesheet/static/SVM/finalizedSVM_model.sav'
			loaded_model = pickle.load(open(filename, 'rb'))
			result = loaded_model.predict(the_data)


	#do something woth the data that you just received e.g run a model
	#save the data in a database
	#json.dumps(result)
	return HttpResponse(json.dumps(result), content_type = 'application/json')
	


@ensure_csrf_cookie
def SVMpage(request):
	return render(request, 'balancesheet/SVM.html')	
	
